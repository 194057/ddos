We moved documentation to our [site](https://fastnetmon.com/subnet-collection-from-bgp-peering-session/)
