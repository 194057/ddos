#ifndef FAST_DPI_H
#define FAST_DPI_H

#include "libndpi/ndpi_api.h"
#include <stdlib.h>

struct ndpi_detection_module_struct* init_ndpi();

#endif
