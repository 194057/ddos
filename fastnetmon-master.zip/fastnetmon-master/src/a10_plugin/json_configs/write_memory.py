write_mem_path = '/axapi/v3/write/memory'
