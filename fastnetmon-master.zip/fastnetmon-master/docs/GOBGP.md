We moved this page to our new [site](https://fastnetmon.com/docs/gobgp-integration/)
