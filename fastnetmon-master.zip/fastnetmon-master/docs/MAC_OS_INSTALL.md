We moved page to our [site](https://fastnetmon.com/fastnetmon-macos/)
