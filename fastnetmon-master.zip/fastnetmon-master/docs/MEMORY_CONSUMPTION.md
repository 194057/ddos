This page was moved to our [site](https://fastnetmon.com/docs/memory_consumption/)
