Page was moved to our [site](https://fastnetmon.com/fastnetmon-community-slackware-install/)
