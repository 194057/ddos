Sorry, we deprecated VyOS support and you need to install FastNetMon manually. 
