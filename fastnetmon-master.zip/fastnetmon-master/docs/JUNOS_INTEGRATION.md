We moved this page to our [site](https://fastnetmon.com/docs/junos_integration/)
