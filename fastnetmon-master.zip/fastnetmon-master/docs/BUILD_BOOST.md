We deprecated this guide. Please us automatic [install script](https://fastnetmon.com/install/) instead.
