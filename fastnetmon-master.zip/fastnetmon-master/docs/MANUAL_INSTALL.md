Please use our suggested automatic [installer tool](https://fastnetmon.com/install/).
