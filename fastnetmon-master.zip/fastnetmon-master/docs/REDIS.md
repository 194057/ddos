Page was moved to our [site](https://fastnetmon.com/docs/redis/)
