Page was moved to our [site](https://fastnetmon.com/installing-netmap-module-for-freebsd-kernel/)
