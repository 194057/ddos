We moved this page to our [site](https://fastnetmon.com/fastnetmon-community-install-on-vyos-1-1-5/)
