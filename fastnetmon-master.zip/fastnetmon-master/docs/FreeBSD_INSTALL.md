Since release 1.1.2 FastNetMon was added into official FreeBSD ports. Please use version from [ports](https://freshports.org/net-mgmt/fastnetmon/) instead.
