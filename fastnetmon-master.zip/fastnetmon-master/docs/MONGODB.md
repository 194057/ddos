We moved thos page to our [site](https://fastnetmon.com/docs/mongodb/)
