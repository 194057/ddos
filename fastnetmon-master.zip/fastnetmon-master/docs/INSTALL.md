We moved this page to our [site](https://fastnetmon.com/install/)
