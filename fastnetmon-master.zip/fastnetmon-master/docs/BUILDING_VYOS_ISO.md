We do not support VyOS images with pre-installed FastNetMon. Ask VyOS project directly about this feature. 
