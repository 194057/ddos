We moved this page to our [site](https://fastnetmon.com/fastnetmon-community-developer-notes/)
