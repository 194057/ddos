Sorry, we've removed and deprecated Amazon images because they had ZERO interest. Let us know if you still need them
