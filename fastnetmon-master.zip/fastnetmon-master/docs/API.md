We moved this page to our site [here](https://fastnetmon.com/fastnetmon-community-api/)
