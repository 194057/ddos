Page moved to our new [site](https://fastnetmon.com/fastnetmon-community-developer-version/)
