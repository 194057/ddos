We moved this page to our [site](https://fastnetmon.com/docs/influxdb_integration/)
