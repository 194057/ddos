We moved this page to our new [site](https://fastnetmon.com/docs/attack_report_example/)
