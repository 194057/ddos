This page was moved to our [site](https://fastnetmon.com/docs/multipe_instances/)
