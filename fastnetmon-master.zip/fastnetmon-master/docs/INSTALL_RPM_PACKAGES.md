We deprecated rpm packages. Please use automatic [install script](https://github.com/pavel-odintsov/fastnetmon/blob/master/docs/INSTALL.md) instead
