We do not maintain this page anymore. Please use standard [release page](https://github.com/pavel-odintsov/fastnetmon/releases)
