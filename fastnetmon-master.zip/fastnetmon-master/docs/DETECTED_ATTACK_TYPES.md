Page moved to our [site](https://fastnetmon.com/docs/detected_attack_types/)
