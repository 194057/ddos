We moved this page to our [site](https://fastnetmon.com/docs/exabgp_integration/)
