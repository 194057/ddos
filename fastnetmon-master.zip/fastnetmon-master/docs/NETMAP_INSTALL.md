We moved this page to our [site](https://fastnetmon.com/netmap-install-on-linux/)
