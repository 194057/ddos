We moved this page to our [site](https://fastnetmon.com/docs/performance_tests/)
