We deprecated any custom Debian packages. Please use upstream packages instead: https://packages.debian.org/sid/fastnetmon 
