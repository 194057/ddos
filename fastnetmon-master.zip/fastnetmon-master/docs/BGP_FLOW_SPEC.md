We migrated this page to our [site](https://fastnetmon.com/docs/bgp_flow_spec/)
