We moved this page to [site](https://fastnetmon.com/docs/graphite_integration/)
